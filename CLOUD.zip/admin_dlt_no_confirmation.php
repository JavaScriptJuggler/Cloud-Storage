<?php include'security.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="HandheldFriendly" content="true">
    <title>Developemnt</title>
    <style type="text/css">
        img {
            height: 25%;
            width: 25%;
            padding-top: 10%;
        }

    </style>

</head>

<body>
    <center>
        <img src="images/anxiety.png">
        <h2>Under development. Will be available soon.</h2>
    </center>
</body>

</html>
