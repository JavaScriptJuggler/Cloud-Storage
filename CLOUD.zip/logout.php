<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="HandheldFriendly" content="true">
    <title>Log Out</title>
    <style type="text/css">
        img {
            height: 25%;
            width: 25%;
            padding-top: 10%;
        }

    </style>

</head>

<body>
    <center>
        <img src="images/no-signal.png">
        <h4>You are logout by server.<a href="index.php">Login</a> </h4>
    </center>
</body>

</html>
